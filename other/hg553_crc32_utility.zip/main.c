#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>


// From Linux kernel source
// http://lxr.free-electrons.com/source/lib/crc32.c#L185

uint32_t crc32_le(uint32_t crc, unsigned char const *p, size_t len)
{	
		int i;
        while (len--) {
                crc ^= *p++;
                for (i = 0; i < 8; i++)
                        crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
        }
        return crc;		
}

int main(int argc, char *argv[]){

    if (argc != 2) {
		printf("Usage: crc32le <filename>\nExiting...\n");
		exit(-1);
    }
    
    FILE *binfile = fopen(argv[1], "rb");
    fseek(binfile, 0, SEEK_END);
    long fsize = ftell(binfile);
    fseek(binfile, 0, SEEK_SET);

    unsigned char *nvram = malloc(fsize);
    fread(nvram, fsize, 1, binfile);
    fclose(binfile);

    uint32_t crc = crc32_le(~0, nvram, fsize);
    
    printf("CRC32: 0x%08x\n", crc);
    exit(0);
}

