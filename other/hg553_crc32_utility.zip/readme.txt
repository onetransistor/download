CRC32 utility compatible with CFE checksums
Based on crc32_le() function from Linux kernel
http://lxr.free-electrons.com/source/lib/crc32.c#L185

***

1. Compile from source
You need gcc compiler. Run this command:

gcc -s -o crc32le main.c

Should work on Windows and Linux too.

2. Usage
- use a hex editor and copy a relevant chunk of binary data into a new file;
- pass this file as an argument to crc32le executable:

crc32le <filename>

- the output is:

CRC32: 0x________

***

This archive should contain:
- this readme.txt file;
- main.c source code;
- crc32le.exe 32 bit executable for Windows.

