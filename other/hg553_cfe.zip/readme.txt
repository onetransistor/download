This archive contains:

- Headerless CFE for Huawei HG553 (ready to burn to flash).
  Based on: https://wiki.openwrt.org/toh/huawei/hg553#unlocking_oem_firmware
- PNG image with NVRAM section info
- this readme file