Huawei HG553 firmware
#####################

Roleo version - Based on D-Link DVA-G3672B

A. About Firmware
-----------------
1. This firmware has ADSL 2+ support.

B. Installation instructions:
-----------------------------
1. Power off the router and disconnect from LAN network.
2. Set computer IP to static 192.168.1.10 with the gateway 192.168.1.1.
3. Press and hold the reset button on the router and turn it on. 
   Keep holding reset for 30-60 seconds.
4. Connect to PC via LAN cable (no other devices should be connected to the 
   router).
5. Open a browser and go to http://192.168.1.1.
6. Browse the firmware and load it by clicking Update Software
7. Wait for the router to restart.
8. Disconnect it from computer and restore LAN settings on computer.
