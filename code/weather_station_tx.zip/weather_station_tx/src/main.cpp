#include <Arduino.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// Uncomment the following line to always send preset data
//#define DEBUG_DATA
#define DB_TEMP 17.0
#define DB_HUM 67
#define DB_DEV 142
#define DB_CH 1
#define DB_BATT HIGH

// The tested device skips first 4 bits on first transmission
// and the sync bit on last transmission
// Uncomment the next line to transmit complete bitstream each time
//#define COMPLETE_TX

// Pulse widths in microseconds (need some adjustments because of FS1000A module)
#define PULSE_HIGH 550  /* 500 us */
#define PULSE_ZERO 940  /* 1000 us */
#define PULSE_ONE 1940  /* 2000 us */
#define PULSE_SYNC 3940 /* 4000 us */

// Time between two TX = 56.75 seconds
#define TX_INTERVAL 56750

// Bitstream repetition (this device sends the information 10 times)
#define DATA_REPEAT 10

// Pin definitions
#define DHT_PIN 2
#define LED_PIN 3
#define TX_PIN 4
#define BTN_PIN 5
#define CH_PIN1 6
#define CH_PIN2 7

LiquidCrystal_I2C lcd(0x27, 16, 2);
DHT dht(DHT_PIN, DHT22);

float t = 0;
unsigned int h = 0;
unsigned long last = 0, b_debounce = 0, ch_check = 0;

byte dev_id;
bool dev_batt;
byte dev_ch;

// ***** Generate the pulse for a single bit *****
void tx_bit(byte onPin, bool b)
{
  digitalWrite(onPin, HIGH);
  delayMicroseconds(PULSE_HIGH);
  digitalWrite(onPin, LOW);
  if (b == true)
    delayMicroseconds(PULSE_ONE);
  else
    delayMicroseconds(PULSE_ZERO);
}

// ***** Generate bitstream (36 bits) *****
void tx_data(byte onPin, bool first = false)
{
  int idx;

  // send ID
  for (first ? idx = 3 : idx = 7; idx >= 0; idx--)
  {
    tx_bit(onPin, dev_id & (0x1 << idx));
  }

  // send battery state
  tx_bit(onPin, dev_batt);

  // send zero
  tx_bit(onPin, LOW);

  // send channel
  tx_bit(onPin, dev_ch & 0x2);
  tx_bit(onPin, dev_ch & 0x1);

  // send temperature (12 bits)
  int16_t t12 = t * 10.0f;
  for (idx = 11; idx >= 0; idx--)
  {
    tx_bit(onPin, t12 & (0x1 << idx));
  }

  // send 1111
  tx_bit(onPin, HIGH);
  tx_bit(onPin, HIGH);
  tx_bit(onPin, HIGH);
  tx_bit(onPin, HIGH);

  // send humidity
  uint8_t h8 = (uint8_t)h;
  for (idx = 7; idx >= 0; idx--)
  {
    tx_bit(onPin, h8 & (0x1 << idx));
  }
}

// ***** Generate full signal (36 bits repeated 10 times) *****
void full_broadcast(byte onPin, byte repeat)
{
#ifdef COMPLETE_TX
  tx_data(onPin, false);
#else
  tx_data(onPin, true);
#endif

  // sync bit
  digitalWrite(onPin, HIGH);
  delayMicroseconds(PULSE_HIGH);
  digitalWrite(onPin, LOW);
  delayMicroseconds(PULSE_SYNC);

  for (int i = 1; i < repeat; i++)
  {
    tx_data(onPin);

#ifndef COMPLETE_TX
    if (i + 1 == repeat)
      break; // do not send sync after last TX
#endif

    // sync bit
    digitalWrite(onPin, HIGH);
    delayMicroseconds(PULSE_HIGH);
    digitalWrite(onPin, LOW);
    delayMicroseconds(PULSE_SYNC);
  }
}

// ***** Read data from sensor, update LCD and transmit RF *****
void read_and_tx()
{
  digitalWrite(LED_PIN, HIGH);

#ifndef DEBUG_DATA
  t = dht.readTemperature(false);
  h = (unsigned int)dht.readHumidity();
#endif

  lcd.setCursor(2, 0);
  lcd.print(t, 1);
  lcd.print(char(223));
  lcd.print("C ");

  lcd.setCursor(13, 0);
  lcd.print(h, DEC);
  lcd.print("%");

  delay(100);

  full_broadcast(TX_PIN, DATA_REPEAT);
  digitalWrite(LED_PIN, LOW);
}

// ***** Set transmit channel *****
void set_channel(bool display = true)
{
  dev_ch = 0;
  if (digitalRead(CH_PIN1) == LOW)
    dev_ch = 1;
  else if (digitalRead(CH_PIN2) == LOW)
    dev_ch = 2;

  if (display)
  {
    lcd.setCursor(14, 1);
    lcd.print(dev_ch + 1, DEC);
  }
}

void setup()
{
  // set pins and hardware
  lcd.init();
  dht.begin();
  pinMode(LED_PIN, OUTPUT);
  pinMode(TX_PIN, OUTPUT);
  pinMode(BTN_PIN, INPUT_PULLUP);
  pinMode(CH_PIN1, INPUT_PULLUP);
  pinMode(CH_PIN2, INPUT_PULLUP);

  digitalWrite(TX_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

// set device information
#ifdef DEBUG_DATA
  dev_id = DB_DEV;
  dev_ch = DB_CH;
  dev_batt = DB_BATT;

  t = DB_TEMP;
  h = DB_HUM;
#else
  dev_id = random(1, 254); // not quite random; it seems to always return 110
  dev_batt = HIGH;
  set_channel(false); // display is not ready
#endif

  // set LCD display
  lcd.clear();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print(" Weather sensor ");

  lcd.setCursor(0, 1);
  lcd.print("Device ");
  lcd.print(dev_id, DEC);

  lcd.setCursor(12, 1);
  lcd.print("CH");
  lcd.print(dev_ch + 1, DEC);

  delay(1000);
  lcd.setCursor(0, 0);
  lcd.print("T=         H=   ");

  // perform first tx
  last = millis();
  read_and_tx();
}

void loop()
{
  unsigned long n = millis();

  // Transmit signal every TX_INTERVAL milliseconds
  if (n > last + TX_INTERVAL)
  {
    last = n;
    read_and_tx();
  }

  // Transmit signal when button pressed
  if ((digitalRead(BTN_PIN) == LOW) && (n > b_debounce + 500))
  {
    b_debounce = n;
    last = n; // set the next TX event after TX_INTERVAL from this one
    read_and_tx();
  }

  // Update channel
  if (n > ch_check + 250)
  {
    ch_check = n;
    set_channel();
  }
}