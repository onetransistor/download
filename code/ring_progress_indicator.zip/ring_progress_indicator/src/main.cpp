#include <Arduino.h>
#include <FastLED.h>
#include <TM1637Display.h>

#define DIS_CLK 2
#define DIS_DIO 3

#define RING_PIN 6
#define NUM_LEDS 24

uint8_t counter = 0;

uint8_t dispData[4] = {0x00, 0x00, 0x00, 0x00};
TM1637Display disp(DIS_CLK, DIS_DIO);
CRGB ring[NUM_LEDS];
uint8_t led_int[5] = {16, 32, 48, 64, 80};

void progress_reset()
{
  counter = 0;

  // 7-segment display
  dispData[1] = disp.encodeDigit(0);
  dispData[2] = disp.encodeDigit(0);
  disp.setSegments(dispData);

  // LED ring
  FastLED.clear();
  ring[14].setHSV(0, 255, led_int[4]);
  FastLED.show();
}

void display_progress(uint8_t progress_val)
{
  if (progress_val > 100)
    progress_val = 100; // range check

  uint8_t d_progress_val = progress_val; // local copy
  dispData[2] = disp.encodeDigit(d_progress_val % 10);
  d_progress_val /= 10;
  if ((d_progress_val % 10 == 0) && (d_progress_val != 10))
    dispData[1] = 0x00;
  else
    dispData[1] = disp.encodeDigit(d_progress_val % 10);
  d_progress_val /= 10;
  if (d_progress_val == 0)
    dispData[0] = 0x00;
  else
    dispData[0] = disp.encodeDigit(1);

  disp.setSegments(dispData);

  // set LED ring
  FastLED.clear();
  ring[14].setHSV(0, 255, led_int[4]);

  for (uint8_t i = 0; i < progress_val; i++)
  {
    uint8_t curr_led = (15 + i / 5) % 24;
    uint8_t curr_led_int = led_int[i % 5];
    uint8_t curr_hue = (i / 5) * 5;
    ring[curr_led].setHSV(curr_hue, 255, curr_led_int);

    /*Serial.print("LED: ");
    Serial.print(curr_led);
    Serial.print(". Hue=");
    Serial.print(curr_hue);
    Serial.print(". Int=");
    Serial.println(curr_led_int);*/
  }
  FastLED.show();
}

void setup()
{
  // Serial.begin(115200);
  delay(2000);

  // turn on 7-segment display
  disp.setBrightness(7, true);

  // init RGB LED ring
  FastLED.addLeds<NEOPIXEL, RING_PIN>(ring, NUM_LEDS);
  FastLED.setBrightness(255);

  display_progress(0);
}

void loop()
{
  for (uint8_t i = 0; i <= 100; i++)
  {
    display_progress(i);
    delay(150);
  }

  delay(2000);

  for (int8_t i = 100; i >= 0; i--)
  {
    display_progress(i);
    delay(150);
  }

  delay(2000);
}