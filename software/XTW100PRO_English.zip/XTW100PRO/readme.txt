XTW100 programmer application
Copyright (c) yaojiedianzi Software, Inc. 2014

Executable modified with Resource Hacker (http://www.angusj.com/resourcehacker/)
Static strings in user interface have been translated to English.
Runtime generated strings cannot be modified (message boxes, logs).