FM Radio Player for RTL2832U USB dongle
---------------------------------------


This software requires Realtek drivers to be installed.
It does not work with libusb driver (for RTL-SDR).

This application is probably an example tool provided
by Realtek for developers.

Origin: from the internet
Copyright: unknown

System Requirements:
- Windows 7 or newer
- KB2731771