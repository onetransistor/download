/*
	Library for Holtek HT16515 VFD Driver with FV865ND/HL-D898W display

	Copyright (C) 2017 One Transistor [https://www.onetransistor.eu]
	
	See: https://www.onetransistor.eu/2017/06/fv865nd-ht16515-arduino.html

	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef HT16515_H
#define HT16515_H

#include "Arduino.h"

// Specific display mode for Futaba FV865ND
// Identical VFD: Hualian HL-D898W
#define DISPMODE_FV865ND	0x05 // display mode: 9 digits, 9th being the icons on the left

// Positions of bit 16 icons
#define FV865ND_DOLBY	0
#define FV865ND_DTS		1
#define FV865ND_VIDEO	2
#define FV865ND_AUDIO	3
#define FV865ND_LINK	4
#define FV865ND_HDD		5
#define FV865ND_DISC	6
#define FV865ND_DVB		7
#define FV865ND_DVD		8

// Bits of position 8 icons
// Added + 9 offset to be able to distinguish them from the others
#define FV865ND_EURO	0 + 9
#define FV865ND_PLAY	1 + 9
#define FV865ND_BACK	2 + 9
#define FV865ND_PAUSE	3 + 9
#define FV865ND_FWD		4 + 9
#define FV865ND_REC		6 + 9
#define FV865ND_ARROW	7 + 9
#define FV865ND_RCLOCK	8 + 9 // round clock
#define FV865ND_SCLOCK	9 + 9 // square clock
#define FV865ND_CARD	10 + 9
#define FV865ND_NO_1	11 + 9
#define FV865ND_NO_2	12 + 9
#define FV865ND_KEY		13 + 9
#define FV865ND_16_9	14 + 9
#define FV865ND_USB		15 + 9

#define FV865ND_SEP21	1
#define FV865ND_SEP43	3
#define FV865ND_SEP65	5

/* Pushbuttons used by Comag SL100HD front panel */
#define COMAG_OK	0x01
#define COMAG_MENU	0x02
#define COMAG_PWR	0x04
#define COMAG_VOLUP 0x10
#define COMAG_VOLDN 0x20
#define COMAG_CHUP	0x40
#define COMAG_CHDN	0x80

class HT16515
{
	const unsigned short ht_font[65] =
	{
		0x0000, // Space
		0x0000, // !
		0x0000, // "
		0x0000, // #
		0x0000, // $
		0x0000, // %
		0x0000, // &
		0x0000, // '
		0x0000, // (
		0x0000, // )
		0x0000, // *
		0x0000, // +
		0x0000, // ,
		0x01c0, // -
		0x0000, // .
		0x0000, // /
		0x66b3, // zero
		0x0212, // 1
		0x45d1, // 2
		0x43d1, // 3
		0x03f0, // 4
		0x43e1, // 5
		0x47e1, // 6
		0x2083, //0x0231, // 7
		0x47f1, // 8
		0x43f1, // 9
		0x0000, // :
		0x0000, // ;
		0x0000, // <
		0x0000, // =
		0x0000, // >
		0x0000, // ?
		0x0000, // @
		0x07f1, // A
		0x52d5, // B
		0x4421, // C
		0x5295, // D
		0x45e1, // E
		0x05e1, // F
		0x4661, // G
		0x07f0, // H
		0x1084, // I
		0x4610, // J
		0x0da2, // K
		0x4420, // L
		0x06ba, // M
		0x0eb8, // N
		0x4631, // 0
		0x05f1, // P
		0x4e31, // Q
		0x0df1, // R
		0x42c9, // S
		0x1085, // T
		0x4630, // U
		0x24a2, // V
		0x5630, // W
		0x288a, // X
		0x108a, // Y
		0x6083, // Z
		0x0000, // [
		0x0000, // backslash
		0x0000, // ]
		0x0000, // ^
		0x0000, // _
		0x0000  // `
	};

public:
	// constructor
	HT16515(int clockPin, int csPin, int dataWritePin, int dataReadPin);
	
	// HT16515 specific
	void clearBuffer();
	void writeBuffer();
	void readKeyMatrix();
	
	// call in setup()
	void init(int intensity = 4); // intensity = 0..7 or -1 to keep it turned off
	void setIntensity(int intensity = -1); // intensity = 0..7 or -1 to keep it turned off
	
	// FV865ND buffer manipulation routines; require writeBuffer() to apply
	void FV865ND_setChar(unsigned char c, unsigned char pos);
	void FV865ND_setDigit(unsigned char digit, unsigned char pos);
	void FV865ND_setIcon(unsigned char icon, bool on = true); // one at a time
	void FV865ND_setSeparator(unsigned char position, bool on = true); // one at a time
	
	// general high level
	void writeStr(char str[8]); // from left to right
	void writeNum(long int num, unsigned char base = 10, unsigned char startpos = 0); // from right to left

	// Comag pushbuttons
	unsigned char getComagPushbuttons();

private:
	int ht_clk, ht_cs, ht_di, ht_do;
	unsigned char ht_buffer[36];
	unsigned char ht_keys[4];

	void sendByte(unsigned char data);
	unsigned char receiveByte();
	void sendCommand(unsigned char data, bool endTransfer = false);

};

#endif
