/*
	Library for Holtek HT16515 VFD Driver with FV865ND/HL-D898W display

	Copyright (C) 2017 One Transistor [https://www.onetransistor.eu]
	
	See: https://www.onetransistor.eu/2017/06/fv865nd-ht16515-arduino.html

	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


/* Command 1: Display mode setting (display is OFF after it)
 * Command 2: Data setting (mode: R/W, address increment)
 * Command 3: Address setting (start address)
 * Command 4: Display control (ON/OFF, intensity) 
 
  -- may be sent in any order and only the ones needed
*/
 

#include "Arduino.h"
#include "HT16515.h"

HT16515::HT16515(int clockPin, int csPin, int dataWritePin, int dataReadPin)
{
	ht_clk = clockPin;
	ht_cs = csPin;
	ht_di = dataWritePin;
	ht_do = dataReadPin;
}

/***** HT16515 Data transmission (low level API) *****/
void HT16515::sendByte(unsigned char data)
{
	for (int i = 0; i < 8; i++)
		{
			digitalWrite(ht_clk, LOW);
			digitalWrite(ht_di, data & 1 ? HIGH : LOW);
			data >>= 1;
			digitalWrite(ht_clk, HIGH);
		}
}

unsigned char HT16515::receiveByte()
{
	unsigned char temp = 0;
	
	for (unsigned char i = 0; i < 8; i++) {
		temp >>= 1;
		delayMicroseconds(2);
		
		digitalWrite(ht_clk, LOW);
		
		if (digitalRead(ht_do))
			temp |= 0x80;
		
		digitalWrite(ht_clk, HIGH);
	}

	return temp;
}

void HT16515::sendCommand(unsigned char data, bool endTransfer)
{
	digitalWrite(ht_cs, HIGH);
	delayMicroseconds(2);
	digitalWrite(ht_cs, LOW);
	sendByte(data);
	
	if (endTransfer) {
		digitalWrite(ht_cs, HIGH);
		delayMicroseconds(2);
	}
}

/***** HT16515 operations (medium level API) *****/
void HT16515::clearBuffer()
{
	for (int i = 0; i < 36; i++)
		ht_buffer[i] = 0x00;
}

void HT16515::writeBuffer()
{
	sendCommand(0x40); // data setting
	sendCommand(0xC0); // address setting
	
	for (int i = 0; i < 36; i++)
		sendByte(ht_buffer[i]);
	
	digitalWrite(ht_cs, HIGH); // end transmission
}

void HT16515::readKeyMatrix()
{    
	sendCommand(0x42); // data setting
	
	for (unsigned char i = 0; i < 4; i++)
		ht_keys[i] = receiveByte();
	
	digitalWrite(ht_cs, HIGH);
}

/***** FV865ND specific functions *****/
void HT16515::FV865ND_setChar(unsigned char c, unsigned char pos)
{
	unsigned char offset = (pos % 8) * 3;
	c -= 0x20; // for ASCII

	for (unsigned char i = 0; i < 15; i++)
		bitWrite(ht_buffer[offset + i / 8], i % 8, bitRead(ht_font[c], i));
}

void HT16515::FV865ND_setDigit(unsigned char digit, unsigned char pos)
{
	unsigned char offset = (pos % 8) * 3;
	unsigned char fontOff = 0x10;
	digit %= 16; // limit digit from 0 to F (hexadecimal are allowed)
	
	if (digit > 9)
		fontOff = 0x17;

	for (unsigned char i = 0; i < 15; i++)
		bitWrite(ht_buffer[offset + i / 8], i % 8, bitRead(ht_font[digit + fontOff], i));
}

void HT16515::FV865ND_setIcon(unsigned char icon, bool on)
{
	unsigned char ipos, ibit;
	
	icon %= 25; // icon assignments are from 0 to 24
	
	if (icon < 9) { // top icons
		ibit = 16; // on bit 16
		ipos = icon;
	}
	else { // left icons
		ibit = icon - 9;
		ipos = 8; // at 9th position
	}
	
	ipos *= 3; // compute the offset (a position is 3 bytes wide)
	
	bitWrite(ht_buffer[ipos + ibit / 8], ibit % 8, on);
}

void HT16515::FV865ND_setSeparator(unsigned char position, bool on)
{
	unsigned char pos = position * 3;
	
	bitWrite(ht_buffer[pos + 1], 7, on);
	bitWrite(ht_buffer[pos + 2], 7, on);
}

/***** Initialization and light intensity *****/
void HT16515::init(int intensity)
{
	pinMode(ht_clk, OUTPUT);
	pinMode(ht_cs, OUTPUT);
	pinMode(ht_di, OUTPUT);
	pinMode(ht_do, INPUT);

	digitalWrite(ht_clk, HIGH);
	digitalWrite(ht_cs, HIGH);
	
	clearBuffer();
	delay(100);

	sendCommand(DISPMODE_FV865ND);
	setIntensity(intensity);
	
	delay(100);
}

void HT16515::setIntensity(int intensity)
{
	if (intensity < 0)
		sendCommand(0x80); // turn off
	else
		sendCommand(0x88 | min(intensity, 7)); // control display
	
	digitalWrite(ht_cs, HIGH);
}

/***** High level API *****/
void HT16515::writeStr(char str[8])
{
	for (char i = 7; i >= 0; i--)
		if (str[7 - i])
			{
				char c = str[7 - i];
				FV865ND_setChar(c, i);
			}
		else break;
		
	writeBuffer();
}

void HT16515::writeNum(long int num, unsigned char base, unsigned char startpos)
{
	if ((startpos > 7) || (base < 2) || (base > 16))
		return;
	
	bool negative = false;
	if (num < 0) negative = true;
	num = abs(num);

	unsigned char pos = startpos;

	do
		{
			FV865ND_setDigit(num % base, pos);
			num = num / base;
			pos++;
		}
	while ((num > 0) && (pos < 8));

	if ((pos < 8) && (negative))
		FV865ND_setChar('-', pos);
	
	writeBuffer();
}

/***** Specific Comag pushbuttons *****/
unsigned char HT16515::getComagPushbuttons() {
	readKeyMatrix();
	
	return ht_keys[0];
}













